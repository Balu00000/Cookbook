import { Routes } from '@angular/router';
import { NavbarComponent } from './navbar/navbar.component';
import { RegisterComponent } from './register/register.component';
import { DiscoverComponent } from './discover/discover.component';
import { RandomComponent } from './random/random.component';
import { HomeComponent } from './home/home.component';

export const routes: Routes = [
    {path: "", redirectTo:"/home", pathMatch: 'full'},
    {path: "home", component: HomeComponent},
    {path: "register", component: RegisterComponent},
    {path: "discover", component: DiscoverComponent},
    {path: "random", component:RandomComponent}
];
