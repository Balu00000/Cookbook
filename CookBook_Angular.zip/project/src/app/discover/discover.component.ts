import { Component, ElementRef, ViewChild, Renderer2, ChangeDetectorRef } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-discover',
  standalone: true,
  imports: [NavbarComponent, CommonModule],
  templateUrl: './discover.component.html',
  styleUrl: './discover.component.css'
})
export class DiscoverComponent {

  isDropdownOpen: boolean = false;

  difficulties: { name: string }[] = []
  mealTypes: { name: string }[] = []

  baseURL: string = "http://127.0.0.1:8080/CookBook-1.0-SNAPSHOT/webresources/"

  dropdowns: { [key: string]: { isOpen: boolean; data: string[] } } = {};

  constructor(private cdr: ChangeDetectorRef) { }

  // Initialize dropdowns
  ngOnInit(): void {
    this.initializeDropdown('difficulty', 'http://127.0.0.1:8080/CookBook-1.0-SNAPSHOT/webresources/difficulty/getAllDifficulty');
    this.initializeDropdown('mealType', 'http://127.0.0.1:8080/CookBook-1.0-SNAPSHOT/webresources/mealType/getAllMealType');
  }

  async initializeDropdown(key: string, url: string): Promise<void> {
    this.dropdowns[key] = { isOpen: false, data: [] }; // Initialize state
    try {
      const response = await fetch(url);
      const result = await response.json();
      this.dropdowns[key].data = result.result.map((item: any) => item.name); // Assuming API returns array with "name"
      this.cdr.detectChanges(); // Ensure UI updates
    } catch (error) {
      console.error(`Failed to fetch data for ${key}:`, error);
    }
  }

  /*difficulties:{name:string }[] = []
  mealTypes:{name:string }[] = []
  mealTypes:{name:string }[] = []
  difficulties:{name:string }[] = []*/

  @ViewChild('veryDiv') veryDiv!: ElementRef<HTMLDivElement>;
  @ViewChild('mhm') mhmDiv!: ElementRef<HTMLDivElement>;

  async difficulty(key: string) {
    try {
      const difficultyResponse = await fetch(this.baseURL + "difficulty/getAllDifficulty")
      const difficultyData = await difficultyResponse.json()
      if (!difficultyData.ok) {
        console.error('Failed to fetch difficulties.');
      }

      console.log(difficultyData);
      this.difficulties = difficultyData.result
      console.log(this.difficulties);

      //this.isDropdownOpen = !this.isDropdownOpen; // Toggle visibility
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  async mealType(key:string) {
    try {
      const mealTypeResponse = await fetch(this.baseURL + "mealType/getAllMealType")
      const mealTypeData = await mealTypeResponse.json()
      if (!mealTypeData.ok) {
        console.error('Failed to fetch difficulties.');
      }

      console.log(mealTypeData);
      this.difficulties = mealTypeData.result
      console.log(this.difficulties);

      this.dropdowns[key].isOpen = !this.dropdowns[key].isOpen;
      this.cdr.detectChanges(); // Trigger UI update
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }
}
